import Foundation
import UIKit
import XCPlayground

public protocol ClassIdentifiable {
    static func identifier() -> String
}

extension NSObject : ClassIdentifiable {
    public static func identifier() -> String {
        return String(describing: self)
    }
}

public enum RegisterableView {
    case nib(NSObject.Type)
    case `class`(NSObject.Type)
}

public extension RegisterableView {
    public var nib: UINib? {
        switch self {
        case let .nib(cellClass):
            return UINib(nibName: String(describing: cellClass), bundle: nil)
        default:
            return nil
        }
    }

    public var identifier: String {
        switch self {
        case let .nib(cellClass):
            return cellClass.identifier()
        case let .class(cellClass):
            return cellClass.identifier()
        }
    }

    public var cellClass: AnyClass? {
        switch self {
        case let .class(cellClass): return cellClass
        default: return nil
        }
    }
}

public protocol CollectionView {
    func register(cell: RegisterableView)
    func register(header: RegisterableView)
    func register(footer: RegisterableView)
}

public extension CollectionView {
    public func register(cells: [RegisterableView]) {
        cells.forEach(register(cell:))
    }

    public func register(headers: [RegisterableView]) {
        headers.forEach(register(header:))
    }

    public func register(footers: [RegisterableView]) {
        footers.forEach(register(footer:))
    }
}

extension UITableView : CollectionView {
    public func register(cell: RegisterableView) {
        switch cell {
        case .nib:
            register(cell.nib, forCellReuseIdentifier: cell.identifier)
        case .class:
            register(cell.cellClass, forCellReuseIdentifier: cell.identifier)
        }
    }

    public func register(header: RegisterableView) {
        switch header {
        case .nib:
            register(header.nib, forHeaderFooterViewReuseIdentifier: header.identifier)
        case .class:
            register(header.cellClass, forHeaderFooterViewReuseIdentifier: header.identifier)
        }
    }

    public func register(footer: RegisterableView) {
        register(header: footer)
    }
}

extension UICollectionView : CollectionView {
    public func register(cell: RegisterableView) {
        switch cell {
        case .nib:
            register(cell.nib, forCellWithReuseIdentifier: cell.identifier)
        case .class:
            register(cell.cellClass, forCellWithReuseIdentifier: cell.identifier)
        }
    }

    public func register(header: RegisterableView) {
        register(supplementaryView: header, kind: UICollectionElementKindSectionHeader)
    }

    public func register(footer: RegisterableView) {
        register(supplementaryView: footer, kind: UICollectionElementKindSectionFooter)
    }

    private func register(supplementaryView view: RegisterableView, kind: String) {
        switch view {
        case .nib:
            register(view.nib, forSupplementaryViewOfKind:kind , withReuseIdentifier: view.identifier)
        case .class:
            register(view.cellClass, forSupplementaryViewOfKind:kind , withReuseIdentifier: view.identifier)
        }
    }
}

extension UITableView {
    public func dequeueCell<U: ClassIdentifiable>(at indexPath: IndexPath) -> U {
        return dequeueReusableCell(withIdentifier: U.identifier(), for: indexPath) as! U
    }

    public func dequeueHeader<U: ClassIdentifiable>() -> U {
        return dequeueReusableHeaderFooterView(withIdentifier: U.identifier()) as! U
    }

    public func dequeueFooter<U: ClassIdentifiable>() -> U {
        return dequeueHeader()
    }
}

extension UICollectionView {
    public func dequeueCell<U: ClassIdentifiable>(at indexPath: IndexPath) -> U {
        return dequeueReusableCell(withReuseIdentifier: U.identifier(), for: indexPath) as! U
    }

    public func dequeueHeader<U: ClassIdentifiable>(at indexPath: IndexPath) -> U {
        return dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: U.identifier(), for: indexPath) as! U
    }

    public func dequeueFooter<U: ClassIdentifiable>(at indexPath: IndexPath) -> U {
        return dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: U.identifier(), for: indexPath) as! U
    }
}

// Test

class MyTableViewCell: UITableViewCell {
    func configure(with title: String) {
        textLabel?.text = title
    }
}

class MyTableViewController: UITableViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let cells: [RegisterableView] = [
            .class(MyTableViewCell.self)
        ]
        tableView.register(cells: cells)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: MyTableViewCell = tableView.dequeueCell(at: indexPath)
        cell.configure(with: "Row \(indexPath.row)")
        return cell
    }
}

import PlaygroundSupport
let tableViewController = MyTableViewController(style: .grouped)
PlaygroundPage.current.liveView = tableViewController
